package com.example.practica04;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public EditText editTextNombre;
    public EditText editTextApellido;
    public EditText editTextEdad;
    public TextView txt_nombre;
    public TextView txt_apellido;
    public TextView txt_edad;
    public Button ir_activity2;
    public Button ver_c;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextNombre = (EditText) findViewById(R.id.editTextNombre);
        editTextApellido = (EditText) findViewById(R.id.editTextApellidos);
        editTextEdad = (EditText) findViewById(R.id.editTextEdad);
        txt_nombre = (TextView) findViewById(R.id.txt_nombre);
        txt_apellido = (TextView) findViewById(R.id.txt_apellidos);
        txt_edad = (TextView) findViewById(R.id.txt_edad);
        ir_activity2 = (Button) findViewById(R.id.btn_registrar);
        ver_c = (Button) findViewById(R.id.btn_ver);



    }

        public void OnClick(View view){
        switch(view.getId()){
            case R.id.btn_registrar:
                guardarpreferencias();
                break;
            case R.id.btn_ver:
                cargarpreferencias();
                Intent intent = new Intent(this, MainActivity2.class);
                startActivity(intent);
        }
    }




    public void guardarpreferencias(){
        SharedPreferences preferences = getSharedPreferences("credenciales", Context.MODE_PRIVATE);
        String nombre = editTextNombre.getText().toString();
        String apellidos = editTextApellido.getText().toString();
        int edad = Integer.parseInt(editTextEdad.toString());

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("nombre", nombre);
        editor.putString("apellidos", apellidos);
        editor.putInt("edad", edad);

        txt_nombre.setText(nombre);
        txt_apellido.setText(apellidos);
        txt_edad.setText(edad);

        editor.commit();
    }
    public void cargarpreferencias()
    {
        SharedPreferences preferences = getSharedPreferences("credenciales", Context.MODE_PRIVATE);
        String nombre= preferences.getString("nombre", "No existe la información");
        String apellidos = preferences.getString("apellidos", "No existe la información");
        int edad = preferences.getInt("edad", 0);

        txt_nombre.setText(nombre);
        txt_apellido.setText(apellidos);
        txt_edad.setText(edad);
    }
}